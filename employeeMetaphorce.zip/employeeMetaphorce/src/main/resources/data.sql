INSERT INTO MetaphorceBd.contract_type(date_created,description,name,is_active) values(NOW(),'Employee Permanent','Permanent',true);
INSERT INTO MetaphorceBd.contract_type(date_created,description,name,is_active) values(NOW(),'Employee Fixed-Term','Fixed-Term',true);
INSERT INTO MetaphorceBd.contract_type(date_created,description,name,is_active) values(NOW(),'Employee External','External',true);