package com.metaphorce.mx.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.metaphorce.mx.model.Employee;
import com.metaphorce.mx.resources.Resources;
import com.metaphorce.mx.service.EmployeeService;
import com.metaphorce.mx.vo.EmployeeVO;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {
	private EmployeeService employeeService;

	public EmployeeController(EmployeeService employeeService) {
		super();
		this.employeeService = employeeService;
	}
	
	@PostMapping()
	public ResponseEntity<String> saveEmployee(@RequestBody EmployeeVO employee) throws ParseException{
		
		/*Validate taxIdNumber*/
		Resources resources=new Resources();
		boolean isCorrect=resources.validatedTaxID(employee.getTaxIdNumber());
		if(!isCorrect) {
			return new ResponseEntity<String>("Error in field TaxIdNumber, employee not created.",HttpStatus.BAD_REQUEST);
		}		
		
		boolean isExist=employeeService.isExistTaxIdNum(employee.getTaxIdNumber());
		
		if(isExist) {
			return new ResponseEntity<String>("Employee exist.",HttpStatus.FOUND);
		}
		
		Employee emp= new Employee();
		emp.setTaxIdNumber(employee.getTaxIdNumber());
		emp.setName(employee.getName());
		emp.setLastName(employee.getLastName());
		emp.setBirthDate(new SimpleDateFormat("dd/MM/yyyy").parse(employee.getBirthDate()));
		emp.setEmail(employee.getEmail());
		emp.setCellPhone(employee.getCellPhone());
		emp.setActive(employee.isActive());		
		emp.setDateCreated(new SimpleDateFormat("dd/MM/yyyy").parse(employee.getDateCreated()));
		employeeService.saveEmployee(emp);
		
		return new ResponseEntity<String>("Employee Created.",HttpStatus.CREATED);
	}
}
