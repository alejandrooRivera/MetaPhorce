package com.metaphorce.mx.service;

import com.metaphorce.mx.model.Employee;

public interface EmployeeService {
	Employee saveEmployee(Employee employee);
	boolean isExistTaxIdNum(String taxIdNum);
}
