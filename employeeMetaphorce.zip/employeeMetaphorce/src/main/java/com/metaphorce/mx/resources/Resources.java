package com.metaphorce.mx.resources;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Resources {
	public boolean validatedTaxID(String taxidNum){
		if (taxidNum == null) { 
            return false; 
        } 
		taxidNum=taxidNum.toUpperCase().trim();
		String regex="[A-Z]{4}[0-9]{6}[A-Z,0-9]{3}";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(taxidNum);
		return m.matches(); 
	}
}
