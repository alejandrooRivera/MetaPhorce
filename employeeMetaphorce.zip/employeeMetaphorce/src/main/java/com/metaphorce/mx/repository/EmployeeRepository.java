package com.metaphorce.mx.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.metaphorce.mx.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer>{

	@Query("SELECT CASE WHEN COUNT(tax_id_number) > 0 THEN true ELSE false END FROM Employee WHERE tax_id_number = :taxIdNum")	        
    boolean existsByTaxIdNumber(@Param("taxIdNum") String taxIdNum);

}
