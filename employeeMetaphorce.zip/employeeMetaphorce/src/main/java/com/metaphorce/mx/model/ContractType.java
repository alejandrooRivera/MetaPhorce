package com.metaphorce.mx.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "ContractType")
public class ContractType {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private short ContractTypeId;
	
	@Column(columnDefinition = "varchar(80)", nullable = false)
	private String Name;
	
	@Column(columnDefinition = "varchar(255)", nullable = true)
	private String Description;
	
	@Column(nullable = false)
	private boolean isActive;
	
	@Column(columnDefinition = "datetime", nullable = false)
	private Date DateCreated;
	
	/*Foreign Key*/
	@OneToOne(mappedBy = "contractType")
	private Contract contract;
}
