package com.metaphorce.mx.model;

import java.math.BigInteger;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "Contract")
public class Contract {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ContractId", columnDefinition = "bigint" )
	private BigInteger ContractId;
	
	/*Foreign Key*/
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "employee_id" , referencedColumnName = "EmployeeId")
	private Employee employee;
	
	/*Foreign Key*/
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "contractType_id" , referencedColumnName = "ContractTypeId")
	private ContractType contractType;
	
	@Column(columnDefinition = "datetime", nullable = false)
	private Date DateFrom;
	
	@Column(columnDefinition = "datetime", nullable = false)
	private Date DateTo;
	
	@Column(columnDefinition = "decimal", nullable = false)
	private double SalaryPerDay;
	
	@Column(nullable = false)
	private boolean isActive;
	
	@Column(columnDefinition = "datetime", nullable = false)
	private Date DateCreated;
	
}
