package com.metaphorce.mx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeMetaphorceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeMetaphorceApplication.class, args);
	}

}
