package com.metaphorce.mx.vo;

import java.util.Date;

public class EmployeeVO {
	private String TaxIdNumber;
	private String Name;
	private String LastName;
	private String BirthDate;
	private String Email;
	private String CellPhone;
	private boolean isActive;
	private String DateCreated;
	
	public String getTaxIdNumber() {
		return TaxIdNumber;
	}
	public void setTaxIdNumber(String TaxIdNumber) {
		this.TaxIdNumber = TaxIdNumber;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getBirthDate() {
		return BirthDate;
	}
	public void setBirthDate(String birthDate) {
		BirthDate = birthDate;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getCellPhone() {
		return CellPhone;
	}
	public void setCellPhone(String cellPhone) {
		CellPhone = cellPhone;
	}
	public boolean isActive() {
		return isActive;
	}
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	public String getDateCreated() {
		return DateCreated;
	}
	public void setDateCreated(String dateCreated) {
		DateCreated = dateCreated;
	}
}
