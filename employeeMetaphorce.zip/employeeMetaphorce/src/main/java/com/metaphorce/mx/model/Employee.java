package com.metaphorce.mx.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "Employee")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer EmployeeId;
	
	@Column(name ="TaxIdNumber", columnDefinition = "varchar(13)", nullable = false)
	private String TaxIdNumber;

	@Column(columnDefinition = "varchar(60)", nullable = true)
	private String Name;
	
	@Column(columnDefinition = "varchar(120)", nullable = true)
	private String LastName;
	
	@Column(columnDefinition = "date", nullable = true)
	private Date BirthDate;
	
	@Column(columnDefinition = "varchar(60)", nullable = true)
	private String Email;
	
	@Column(columnDefinition = "varchar(20)", nullable = true)
	private String CellPhone;
	
	@Column(nullable = true)
	private boolean isActive;
	
	@Column(columnDefinition = "datetime", nullable = true)
	private Date DateCreated;

	public String getTaxIdNumber() {
		return TaxIdNumber;
	}

	public void setTaxIdNumber(String taxIdNumber) {
		TaxIdNumber = taxIdNumber;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public Date getBirthDate() {
		return BirthDate;
	}

	public void setBirthDate(Date birthDate) {
		BirthDate = birthDate;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getCellPhone() {
		return CellPhone;
	}

	public void setCellPhone(String cellPhone) {
		CellPhone = cellPhone;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public Date getDateCreated() {
		return DateCreated;
	}

	public void setDateCreated(Date dateCreated) {
		DateCreated = dateCreated;
	}
	
	/*Foreign Key*/	
	/*@OneToOne(mappedBy = "employee")
	private Contract contract;*/
	
	
	
}
