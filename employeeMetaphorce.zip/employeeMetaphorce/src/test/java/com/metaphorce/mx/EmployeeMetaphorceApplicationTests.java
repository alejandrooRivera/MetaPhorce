package com.metaphorce.mx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeMetaphorceApplicationTests {

	@Test
	void contextLoads() {
	}

}
